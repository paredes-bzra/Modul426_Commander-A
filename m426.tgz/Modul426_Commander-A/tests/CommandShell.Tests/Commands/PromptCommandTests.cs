using CommandShell.Core;
using CommandShell.Tests.Fakes;

namespace CommandShell.Tests;

[TestClass]
public class PromptCommandTests
{
    private FakeConsoleService _console = null!;
    private CommandInvoker _invoker = null!;

    [TestInitialize]
    public void Setup()
    {
        _console = new FakeConsoleService();
        _invoker = new CommandInvoker(new Parser(), new FakeFileSystemService(), _console);
    }

    [TestMethod]
    public void Execute_WithText_SetsPrompt()
    {
        _invoker.ExecuteCommand("prompt Daniel $P$G");

        Assert.AreEqual("Daniel $P$G", _console.Prompt);
    }

    [TestMethod]
    public void Execute_WithoutText_SetsDefault()
    {
        _invoker.ExecuteCommand("prompt Test");

        _invoker.ExecuteCommand("prompt");

        Assert.AreEqual("$P$G", _console.Prompt);
    }
}
