using CommandShell.Core;
using CommandShell.Tests.Fakes;

namespace CommandShell.Tests;

[TestClass]
public class ShellTests
{
    private readonly FakeFileSystemService _fakeFileSystemService = new FakeFileSystemService();
    private readonly FakeConsoleService _consoleService = new FakeConsoleService();
    private readonly ShellContext _context = ShellContext.CreateDefault();
    private Shell _shell = null!;

    [TestInitialize]
    public void Setup()
    {
        var invoker = new CommandInvoker(new Parser(), _fakeFileSystemService, _consoleService);
        _shell = new Shell(invoker, _consoleService, _fakeFileSystemService, _context);
    }

    [TestMethod]
    public void Run_NoPromptSaved_ShowsDefaultPrompt()
    {
        _fakeFileSystemService.CurrentDirectory = @"C:\Temp";

        _shell.Run();

        Assert.AreEqual(@"C:\Temp>", _consoleService.Output[0]);
    }

    [TestMethod]
    public void Run_CustomPrompt_ShowsCustomPrompt()
    {
        _fakeFileSystemService.CurrentDirectory = @"C:\Temp";
        _context.Prompt = "Daniel $P$G";

        _shell.Run();

        Assert.AreEqual(@"Daniel C:\Temp>", _consoleService.Output[0]);
    }
}
