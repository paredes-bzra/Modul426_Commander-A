using System.Text;
using CommandShell.Services;

namespace CommandShell.Core;

public class Shell
{
    private readonly CommandInvoker _invoker;
    private readonly IConsoleService _console;
    private readonly IFileSystemService _fileSystem;
    private readonly ShellContext _context;

    public Shell(CommandInvoker invoker, IConsoleService console, IFileSystemService fileSystem, ShellContext context)
    {
        _invoker = invoker;
        _console = console;
        _fileSystem = fileSystem;
        _context = context;
    }

    public void Run()
    {
        _console.SetColor(_context.BackgroundColor, _context.ForegroundColor);

        bool running = true;
        while (running)
        {
            DisplayPrompt();
            string? input = _console.ReadLine();
            if (input == null)
            {
                break;
            }

            CommandResult result = _invoker.ExecuteCommand(input);
            if (!string.IsNullOrEmpty(result.OutputMessage))
            {
                _console.WriteLine(result.OutputMessage);
            }

            running = !result.ShouldExit;
        }
    }

    private void DisplayPrompt()
    {
        _console.Write(FormatPrompt(_context.Prompt));
    }

    private string FormatPrompt(string format)
    {
        var text = new StringBuilder();

        for (int i = 0; i < format.Length; i++)
        {
            if (format[i] != '$' || i == format.Length - 1)
            {
                text.Append(format[i]);
                continue;
            }

            i++;
            switch (char.ToUpper(format[i]))
            {
                case 'P': text.Append(_fileSystem.CurrentDirectory); break;
                case 'G': text.Append('>'); break;
                case 'L': text.Append('<'); break;
                case 'S': text.Append(' '); break;
                case 'D': text.Append(DateTime.Now.ToString("dd.MM.yyyy")); break;
                case 'T': text.Append(DateTime.Now.ToString("HH:mm:ss")); break;
                case '$': text.Append('$'); break;
                default: text.Append('$').Append(format[i]); break;
            }
        }

        return text.ToString();
    }
}