using CommandShell.Core;
using CommandShell.Services;

namespace CommandShell.Commands;

public class PromptCommand : Command
{
    public PromptCommand(IFileSystemService fileService, IConsoleService consoleService)
        : base(fileService, consoleService)
    {
    }

    public override string Name => "prompt";

    public override string Description => "Ändert den Prompt ($P = Pfad, $G = >, $D = Datum, $T = Zeit).";

    public override CommandResult Execute(CommandContext context)
    {
        if (context.Arguments.Count == 0)
        {
            ConsoleService.SetPrompt("$P$G");
            return CommandResult.Ok();
        }

        ConsoleService.SetPrompt(string.Join(" ", context.Arguments));
        return CommandResult.Ok();
    }
}
