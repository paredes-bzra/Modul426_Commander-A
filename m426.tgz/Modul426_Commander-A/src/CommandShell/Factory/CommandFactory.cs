using CommandShell.Commands;
using CommandShell.Services;

namespace CommandShell.Factory;

public static class CommandFactory
{
    private static readonly Dictionary<string, Func<IFileSystemService, IConsoleService, Command>> Commands =
        new(StringComparer.OrdinalIgnoreCase)
        {
            //für jeden neuen Command das hier machen
            { "exit", (f, c) => new ExitCommand(f, c) },
            { "rename", (f, c) => new RenCommand(f, c) },
            { "ren", (f, c) => new RenCommand(f, c) },
            { "mkdir", (f, c) => new MkdirCommand(f, c) },
            { "md", (f, c) => new MkdirCommand(f, c) },
            { "cls", (f, c) => new ClsCommand(f, c) },
            { "cd", (fs, console) => new CdCommand(fs, console) },
            {"ver", (fs, console) => new VerCommand(fs, console) },
            {"dir", (fs, console) => new DirCommand(fs, console) },
            {"color", (f, c) => new ColorCommand(f, c) },   
            {"del",  (f, c) => new DelCommand(f, c) },
            { "type", (f, c) => new TypeCommand(f, c) },
            { "mkfile", (f, c) => new MkfileCommand(f, c) },
            { "more", (f, c) => new MoreCommand(f, c) },
            { "move", (f, c) => new MoveCommand(f, c) },
            { "prompt", (f, c) => new PromptCommand(f, c) }
            
        };

    public static Command Create(string name, IFileSystemService fileService, IConsoleService consoleService)
    {
        if (Commands.TryGetValue(name, out var create))
        {
            return create(fileService, consoleService);
        }

        return new UnknownCommand(name, fileService, consoleService);
    }

    public static IReadOnlyCollection<string> GetCommands()
    {
        return Commands.Keys;
    }
}
